/*CMD
  command: /info
  help: 
  need_reply: 
  auto_retry_time: 
  folder: 

  <<ANSWER
Xtake.cash 
Universal Blockchain Income
https://www.xtake.cash
  ANSWER
  keyboard: 
  aliases: info ❓
CMD*/

