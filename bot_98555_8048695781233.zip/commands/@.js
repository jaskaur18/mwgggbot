/*CMD
  command: @
  help: 
  need_reply: 
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 
CMD*/

let defaultKeyboard = [
    [ { title: "Visit Our Website And Create A Account", url: "https://www.xtake.cash"} ],

    
       
      [ { title: "Join Our Telegram Group", url:"https://t.me/xtakecash" }
    ],
[ { title: "Join Our Brazilian Telegram Group", url:"https://t.me/xtakecashBR" }
    ],

    [ { title: "Follow US Twitter Page", url:"https://twitter.com/XtakeCash" } ],

     [ { title: "Submit Your Details", command: "/sumbitt" }  ]
]
