/*CMD
  command: /set_twitterusername
  help: 
  need_reply: true
  auto_retry_time: 
  folder: 
  answer: Enter Your Twitter Username ( Without @ )
  keyboard: 
  aliases: 
CMD*/

Bot.sendMessage("Data Successfully Saved ✅")
User.setProperty("twitter_usernams", data.message, "string");
Bot.runCommand('/Home');
