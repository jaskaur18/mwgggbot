/*CMD
  command: /rain
  help: 
  need_reply: 
  auto_retry_time: 
  folder: 
  answer: Rain is coming
  keyboard: 
  aliases: 
CMD*/

