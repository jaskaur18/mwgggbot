/*CMD
  command: /Home
  help: 
  need_reply: 
  auto_retry_time: 
  folder: 
  answer: Welcome To XTK BOT
  keyboard: 💲 Balance 💲,\n ☎️ Help ☎️, \n Info ❓
  aliases: 
CMD*/

