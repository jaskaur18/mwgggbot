/*CMD
  command: /start
  help: 
  need_reply: 
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER
  keyboard: 
  aliases: 
CMD*/

Bot.sendInlineKeyboard(
  defaultKeyboard,
   "Welcome To XTAKE BOT \nPlease Do These Task To Continue")
