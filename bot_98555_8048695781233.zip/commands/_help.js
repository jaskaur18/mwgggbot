/*CMD
  command: /help
  help: 
  need_reply: 
  auto_retry_time: 
  folder: 

  <<ANSWER
The Following Command You Can Use

- /Start - To Start The Bot Or Reset The Bot

-/tip If You Want To A User Reduce From Your Balance

-/Rain Admin Or Moderators Only Get X Amount To X User Randomly

-/Balance To See Balance
  ANSWER
  keyboard: 
  aliases: ☎️ help ☎️
CMD*/

