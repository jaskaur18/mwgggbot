/*CMD
  command: /set_telegramusername
  help: 
  need_reply: true
  auto_retry_time: 
  folder: 
  answer: Enter Your Telegram Username
  keyboard: 
  aliases: 
CMD*/

User.setProperty("telegram_username", data.message, "string");
Bot.runCommand('/set_twitterusername');
