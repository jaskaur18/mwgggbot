/*CMD
  command: /sumbitt
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER
  keyboard: 
  aliases: 
CMD*/

User.setProperty("Mailid", data.message, "string");
Bot.runCommand('/set_telegramusername');
