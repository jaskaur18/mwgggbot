/*CMD
  command: /balance
  help: 
  need_reply: 
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER
  keyboard: 
  aliases: 💲 balance 💲
CMD*/

User.setProperty("Balance",100,"int")
Bot.sendMessage("Hello! " +
   "@"+user.username + " 💲 Your Balance Is  " + User.getProperty("Balance")+ " XTK")
